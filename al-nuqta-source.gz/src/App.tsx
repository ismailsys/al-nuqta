import { useState } from 'react'
import { CheckIn, type Feeling } from './components/CheckIn'
import { Protocol } from './components/Protocol'
import { Sanctuary } from './components/Sanctuary'
import { ApproachModal } from './components/ApproachModal'
import type { Verse } from './data/corpus'
import './styles.css'

type Screen='checkin'|'protocol'|'sanctuary'
export default function App(){
  const [screen,setScreen]=useState<Screen>('checkin')
  const [feelings,setFeelings]=useState<Feeling[]>([])
  const [approach,setApproach]=useState(false)
  const [activeVerse,setActiveVerse]=useState<Verse|null>(null)
  const [sessionOptions,setSessionOptions]=useState({keepText:false,sleep:false})
  function toggle(tag:Feeling){setFeelings(current=>current.includes(tag)?current.filter(x=>x!==tag):current.length<3?[...current,tag]:current)}
  function start(verse:Verse,options:{keepText:boolean;sleep:boolean}){setActiveVerse(verse);setSessionOptions(options);setScreen('sanctuary')}
  return <>
    {screen==='checkin'&&<CheckIn selected={feelings} onToggle={toggle} onGenerate={()=>setScreen('protocol')} onApproach={()=>setApproach(true)}/>}
    {screen==='protocol'&&<Protocol feelings={feelings} onBack={()=>setScreen('checkin')} onStart={start}/>}
    {screen==='sanctuary'&&activeVerse&&<Sanctuary verse={activeVerse} keepText={sessionOptions.keepText} sleep={sessionOptions.sleep} onQuit={()=>setScreen('protocol')}/>}
    {approach&&<ApproachModal onClose={()=>setApproach(false)}/>}
  </>
}
